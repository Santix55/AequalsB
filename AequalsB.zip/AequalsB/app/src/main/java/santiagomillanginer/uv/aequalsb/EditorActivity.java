package santiagomillanginer.uv.aequalsb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class EditorActivity extends AppCompatActivity {

    private EditText editText;
    private final static String NOMBRE_FICHERO = "nivel1.ab";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        editText = findViewById(R.id.editText);

        Button botonGuardar = findViewById(R.id.botonGuardar);
        botonGuardar.setOnClickListener(view -> {
            try {
                File path = getApplicationContext().getFilesDir();
                FileOutputStream fos = new FileOutputStream( new File(path, NOMBRE_FICHERO));
                OutputStreamWriter osw = new OutputStreamWriter(fos);
                osw.write(editText.getText().toString());
                osw.close();
                fos.close();
                Log.d("IO", "nivel1.ab guardado");
            } catch (IOException e) {
                Log.e("ErrorIO", "Error en la escritura");
                e.printStackTrace();
            }
        });

        Button botonCargar = findViewById(R.id.botonCargar);
        botonCargar.setOnClickListener(view -> {
            try{
                File path = getApplicationContext().getFilesDir();
                FileInputStream fis = new FileInputStream(new File(path, NOMBRE_FICHERO));
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader br = new BufferedReader(isr);

                String codigo = "";
                String linea;
                while ((linea=br.readLine()) != null) {
                    codigo += linea;
                }
                editText.setText(codigo);

                br.close();
                isr.close();
                fis.close();
                Log.d("IO", "nivel1.ab leído");
            } catch (IOException e) {
                Log.e("ErrorIO", "Error en la lectura");
                e.printStackTrace();
            }
        });

        Button botonProbar = findViewById(R.id.botonProbar);
        botonProbar.setOnClickListener(view -> {
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra("codigo",editText.getText().toString());
            startActivity(intent);
        });
    }
}