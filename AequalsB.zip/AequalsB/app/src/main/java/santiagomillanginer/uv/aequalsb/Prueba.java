package santiagomillanginer.uv.aequalsb;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author santi
 */
public class Prueba {
    public String input;
    public String output;

    Prueba(String _input, String _output) {
        input = _input; output = _output;
    }

    static ArrayList<Prueba> MIS_PRUEBAS = new ArrayList<>(Arrays.asList(
            new Prueba("abb",""),
            new Prueba("",""),
            new Prueba("ab","FALSE"),
            new Prueba("a","FALSE"),
            new Prueba("babb",""),
            new Prueba("bab","FALSE"),
            new Prueba("babbabb",""),
            new Prueba("abbbabb","")
    ));
}
