package santiagomillanginer.uv.aequalsb;

import java.util.ArrayList;

/**
 *
 * @author santi
 */
public class InterpreteAB {

    private static class Instruccion {
        public String secuenciaAnterior;
        public String secuenciaNueva;

        Instruccion(String _secuenciaAnterior, String _secuenciaNueva){
            this.secuenciaAnterior = _secuenciaAnterior;
            this.secuenciaNueva = _secuenciaNueva;
        }
    }

    public static class Respuesta {
        public String mensaje;
        public boolean correcto;
        public int lineas;
        public int coste;
    }

    /**
     * Compila y ejecuta varios test al código
     * @param codigo   Codigo fuente del programa a compilar y ejecutar
     * @param pruebas  Conjunto de inputs y outputs que deben de coincidir para que este correcto
     * @return         Estructura de datos con los resultados del programa
     */
    public static Respuesta analizar (String codigo, ArrayList<Prueba> pruebas) {
        System.out.println("-- CODIGO A ANALIZAR --");
        System.out.println(codigo);
        System.out.println("-- FIN DE CODIGO A ANALIZAR --");
        System.out.println();

        SalidaCompilacion compilacion = compilar(codigo);
        if(compilacion.mensaje.isEmpty()) {
            // DEBUG
            System.out.println("-- Mostrar instrucciones --");
            for(Instruccion instruccion: compilacion.instrucciones) {
                System.out.println(instruccion.secuenciaAnterior + " = "+instruccion.secuenciaNueva);
            }


            SalidaEjecucion salida = ejecutar(compilacion.instrucciones, pruebas);

            Respuesta res = new Respuesta();
            res.correcto = salida.correcto;
            res.lineas = compilacion.instrucciones.size();
            res.mensaje = salida.output;
            res.coste = salida.coste;

            return res;
        }
        else {
            Respuesta res = new Respuesta();
            res.correcto = false;
            res.mensaje = compilacion.mensaje;
            return res;
        }
    }



    private static class SalidaCompilacion {
        public ArrayList<Instruccion> instrucciones;
        public String mensaje;

        SalidaCompilacion(ArrayList<Instruccion> _instrucciones, String _mensaje) {
            instrucciones = _instrucciones;
            mensaje = _mensaje;
        }
    }

    /**
     * Analiza el código de entrada generando instrucciones.
     * Para de analizar cuando encuentra un error
     * El lenguaje tiene:
     *  - Comentarios con #
     *  - Una sola instrucción que reemplaza str1=str2 (str2 puede ser "")
     * @param codigo Texto de entrada
     * @return Conjunto de instrucciones y mensaje de error, que puede estar vacío si esta correcto
     */
    private static SalidaCompilacion compilar (String codigo) {
        ArrayList<Instruccion> instrucciones = new ArrayList();
        String mensaje = "";    // Mensaje de error
        int linea = 0;

        // Debe de haber un salto de linea al final del código para evitar errores
        if(codigo.charAt(codigo.length()-1)!='\n')
            codigo+="\n";

        // AFD con 3 estados //
        int modo = 1;
        String  str1 = "", str2 = "";  // Cadena actual (1a o 2a)
        final int MODO_COMENTARIO = 0; // Leyendo comentario
        final int MODO_STR1 = 1;       // Leyendo cadena vieja a reemplazar
        final int MODO_STR2 = 2;       // Leyendo cadena nueva


        for(int i=0; i<codigo.length() && mensaje.isEmpty() ; i++) {

            char c = codigo.charAt(i);
            //System.out.println(c+""+modo); // DEBUG


            if (c==' ') {
                // Todos los espacios se ignoran
            }

            else if(modo == MODO_COMENTARIO){
                if(c=='\n') {
                    modo = MODO_STR1;
                    linea++;
                }
            }

            else if (modo == MODO_STR1) {
                switch (c) {
                    case '#':
                    case '\n':
                        // Fin de instruccion (falta str2)
                        if(!str1.isEmpty()){
                            mensaje = "Instruccion incompleta en linea "+linea+"\n";
                            mensaje += "Se esperaba un '=' ";
                        } else {
                            modo = MODO_COMENTARIO;
                        }
                        break;
                    case '=':
                        if(str1.isEmpty()) {
                            mensaje = "Instruccion incompleta en linea "+linea+"\n";
                            mensaje += "Se esperaba una cadena antes del '='";
                        } else {
                            modo = MODO_STR2;
                        }
                        break;
                    default:
                        str1 += c;
                        break;
                }
            }

            else if (modo == MODO_STR2) {
                switch (c) {
                    case '#':
                    case '\n':
                        Instruccion instruccion = new Instruccion(str1, str2);
                        instrucciones.add(instruccion);
                        modo = c=='#'? MODO_COMENTARIO : MODO_STR1;
                        str1 = "";  str2 = "";
                        break;
                    case '=':
                        mensaje = "No puede haber mas de un igual por linea en linea "+linea+"\n";
                        break;
                    default:
                        str2 += c;
                        break;
                }
            }
        }

        return new SalidaCompilacion(instrucciones, mensaje);
    }



    private static class SalidaEjecucion {
        boolean correcto;
        String output;
        int coste;
        SalidaEjecucion(boolean _correcto, String _output, int _coste){
            correcto = _correcto;
            output = _output;
            coste = _coste;
        }
    }

    /**
     * Ejecuta el programa con todos los inputs, mostrando su ejecución.
     * Se termina cuando una salida no coincide con la esperada.
     * Cuando hay una sustitución, vuelve el contador del programa al principio.
     * Si no, lee la siguiente instrucción.
     *
     * @param instrucciones Conjunto de sustitciones
     * @param pruebas Conjunto de inputs y outputs que tienen que coincidir
     * @return
     */
    private static SalidaEjecucion ejecutar(ArrayList<Instruccion> instrucciones, ArrayList<Prueba> pruebas) {
        String output = "";
        int coste = 0;

        for(Prueba prueba: pruebas) {
            output += "\n-- INTPUT: "+prueba.input+" --\n";

            String str = prueba.input;
            for(int i=0; i<instrucciones.size(); i++) {
                Instruccion instruccion = instrucciones.get(i);
                String nuevoStr = str.replaceFirst(instruccion.secuenciaAnterior, instruccion.secuenciaNueva);
                coste ++;

                //System.out.println(i); // DEBUG mostrar contador del programa

                if(!nuevoStr.equals(str)){  // Ha habido reemplazo
                    output += instruccion.secuenciaAnterior +" = "+instruccion.secuenciaNueva;
                    output += " => "+nuevoStr+"\n";

                    // DEBUG
                    System.out.print(instruccion.secuenciaAnterior +" = "+instruccion.secuenciaNueva);
                    System.out.print(" => "+nuevoStr+"\n");

                    str = nuevoStr;
                    i = -1; // Volver al principio
                }
            }

            if(str.equals(prueba.output)) { // Correcto
                output += "-- CORRECTO --\n";
            }
            else {
                output += "-- INCORRECTO (se esperaba:"+prueba.output+")--";
                return new SalidaEjecucion(false, output, coste);
            }
        }

        output += "-- TODO CORRECTO FELICIDADES :D --\n";
        return new SalidaEjecucion(true, output, coste);
    }
}
