package santiagomillanginer.uv.aequalsb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

/**
 * Muestra el enunciado
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (!getIntent().hasExtra("noBucle")) {
            Intent intentSplash = new Intent(this, SplashActivity.class);
            startActivity(intentSplash);
            Log.d("Inicio","No tiene el extra");
        }
        Log.d("Inicio","Tiene el extra");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.botonIrNivel);
        button.setOnClickListener(v -> {
            Intent intent = new Intent(this, EditorActivity.class);
            startActivity(intent);
        });


        TextView textView = findViewById(R.id.enunciado);
        String textoEnunciado = "Dada una cadena formada únicamente por los carácteres 'a' y 'b', "
                + "haz un programa que compruebe que después de cada 'a' hay 2 'b'. Si el programa "
                + "no contiene nignuna 'a' que no este seguida de 'bb' debe de devolver vacío '', "
                + "en caso contrario debe de devolver 'FALSE'.\n"
                + "Por ejemplo:\n"
                + "abb => \n"
                + " => \n"
                + "babbabb => \n"
                + "ab => FALSE \n"
                + "babb => FALSE \n"
                + "bb => \n";
        textView.setText(textoEnunciado);


        TextView records = findViewById(R.id.records);
        RecordsDB recordsDB = new RecordsDB(getApplicationContext());
        Cursor cursor = recordsDB.getRecord();

        if(cursor.moveToNext()) {   // Existe un record

            int lineas = cursor.getInt(0);
            int coste = cursor.getInt(1);
            records.setText("Lineas = "+lineas+"\nCoste = "+coste);
        }
        else {  // No existe un record por tanto el nivel no ha sido superado
            records.setText("Nivel no completado");
        }
    }
}