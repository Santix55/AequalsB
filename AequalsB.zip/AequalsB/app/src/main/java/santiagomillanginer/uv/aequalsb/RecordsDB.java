package santiagomillanginer.uv.aequalsb;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class RecordsDB extends SQLiteOpenHelper {
    private static int DB_VERSION = 1;
    private static String DATABASE_NAME = "RecordsDB";
    private static String TABLE_NAME = "Records";
    public static String LINEAS = "lineas";
    public static String COSTE = "coste";


    public RecordsDB(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+TABLE_NAME+" ("
            +LINEAS+" INTEGER NOT NULL,"
            +COSTE+" INTEGER NOT NULL)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int versionAnterior, int versionActual) {
        Log.d("DB", "Actualizando Base de Datos");
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    public void actualizarRecords (int valLineas, int valCoste) {

        SQLiteDatabase db = this.getWritableDatabase();

        // Insertar nuevo valor si no existe no hay ninguno en la tabla previamente
        db.execSQL("INSERT INTO "+TABLE_NAME+"("+LINEAS+","+COSTE+")"
                +" SELECT "+Integer.MAX_VALUE+","+Integer.MAX_VALUE
                +" FROM (SELECT 1 FROM"+TABLE_NAME+" LIMIT 1)"
        );

        // Actualizar record lineas
        db.execSQL("UPDATE "+TABLE_NAME
                +" SET "+LINEAS+"="
                +" CASE WHEN "+valLineas+"<"+LINEAS+" THEN "+valLineas+" ELSE "+LINEAS+" END"
        );

        // Actualizar record coste
        db.execSQL("UPDATE "+TABLE_NAME
                +" SET "+COSTE+"="
                +" CASE WHEN "+valCoste+"<"+COSTE+" THEN "+valCoste+" ELSE "+COSTE+" END"
        );
    }

    /**
     * Obtiene el record del nivel
     * @return Cursor con el primer elemento lineas y el segundo coste
     */
    public Cursor getRecord () {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT "+LINEAS+", "+COSTE+" FROM "+TABLE_NAME;
        return db.rawQuery(sql, null, null);
    }
}
