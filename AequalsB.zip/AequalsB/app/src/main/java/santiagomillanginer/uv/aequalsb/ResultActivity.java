package santiagomillanginer.uv.aequalsb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Button botonReintentar = findViewById(R.id.botonReintentar);
        botonReintentar.setOnClickListener(view -> onBackPressed());

        Button botonEnunciado = findViewById(R.id.botonEnunciado);
        botonEnunciado.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("noBucle",1);
            startActivity(intent);
        });

        String codigo = getIntent().getStringExtra("codigo");
        InterpreteAB.Respuesta res = InterpreteAB.analizar(codigo, Prueba.MIS_PRUEBAS);

        String mensaje = "";

        MediaPlayer mediaPlayer = MediaPlayer.create(this, res.correcto? R.raw.good : R.raw.bad);
        mediaPlayer.start();

        if(res.correcto) {
            mensaje += "-- NIVEL SUPERADO :D --\n";
            mensaje += " coste = "+res.coste+"\n";
            mensaje += " lineas = "+res.lineas+"\n";

            RecordsDB recordsDB = new RecordsDB(getApplicationContext());
            Cursor cursor = recordsDB.getRecord();

            if (cursor.moveToNext()) { // Existe record anterior
                int recordLineas = cursor.getInt(0);
                int recordCoste = cursor.getInt(1);

                recordsDB.actualizarRecords(res.lineas, res.coste);
                if(res.coste < recordCoste)
                    mensaje += "¡ NUEVO RECORD DE COSTE !";
                if(res.lineas < recordLineas)
                    mensaje += "¡ NUEVO RECORD DE LINEAS !";
                mensaje +="\n";

            } else {
                recordsDB.actualizarRecords(res.lineas, res.coste);
                mensaje += " Puntación guardada\n";
            }
        } else {
            mensaje = "-- NIVEL NO SUPERADO :'( --\n\n";
        }

        TextView output = findViewById(R.id.output);
        output.setText(mensaje+res.mensaje);
    }
}